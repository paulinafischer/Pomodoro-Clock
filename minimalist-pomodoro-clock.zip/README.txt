A Pen created at CodePen.io. You can find this one at https://codepen.io/paulinafischer/pen/xXKYyv.

 Freecodecamp proyect.